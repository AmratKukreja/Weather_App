import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.css';
import { useState, useEffect } from 'react';
import weather_icon from './assets/WeatherIcons.gif'

function App() {
  const [weatherType, setWeatherType] = useState("");
  const [city, setCity] = useState("");
  const [weatherData, setWeatherData] = useState(null);

  const apiURL = `https://api.weatherapi.com/v1/current.json?key=db6449d5f9fa4d35b85150311241102&q=${city}&aqi=no`;

  const fetchWeatherData = () => {
    fetch(apiURL)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Error");
        }
        return response.json();
      })
      .then((data) => {
        console.log(data);
        setWeatherData(data); 
      })
      .catch((e) => {
        console.log(e);
      });
  };

  useEffect(() => {
    if (weatherData) {
      showWeather();
    }
  }, [weatherData]);

  const handleLocationIconClick = () => {
    fetchWeatherData();
  };

  function showWeather() {
    if (weatherData.current) {
      const { wind_mph, humidity, vis_miles, pressure_mb } = weatherData.current;

      if (wind_mph < 5 && humidity > 70) {
        setWeatherType("Sunny");
      } else if (vis_miles < 3) {
        setWeatherType("Foggy");
      } else if (wind_mph > 15 && pressure_mb < 1000) {
        setWeatherType("Stormy");
      } else if (humidity > 80) {
        setWeatherType("Humid");
      } else if (wind_mph < 10 && pressure_mb > 1000) {
        setWeatherType("Partly cloudy");
      } else if (pressure_mb < 1005) {
        setWeatherType("Rainy");
      } else if (wind_mph < 5 && humidity < 50) {
        setWeatherType("Dry and Clear");
      } else {
        setWeatherType("Other");
      }
    }
  }

  return (
    <div id='main'>
      <div id='container1'>
        <div className="card" style={{ width: '16rem', height: '23rem', background: '#333' }}>
          <div id='search-bar'>
            <input type="text" name="country" id="country-field" placeholder='Enter the City' value={city} onChange={(e) => setCity(e.target.value)} />
            <i id='location-icon' className="fa fa-search" aria-hidden="true" onClick={handleLocationIconClick}></i>
          </div>
          <div className="card-body">
            <img src={weather_icon} style={{height:'80px'}} alt="" />
            <div className="d-flex align-items-center">
              <p id='degree'>{weatherData ? weatherData.current.temp_c : ""}</p>
              <i className="circle"></i>
              <p style={{fontSize:'25px',color:'white'}}>C</p>
            </div>
            <p id='mist'>{weatherType}</p>
            <small id='footer-txt'>Today - {weatherData ? weatherData.location.localtime : ''} | {weatherData ? weatherData.location.name : ''}</small>
          </div>
        </div>
      </div>
      <div id='container' >
        <h5 id='today-highlight'>Today's Highlights</h5>
        <div className="row">
          <div className="col-3 d2">Wind Status
            <h1 className='set_margin'>{weatherData ? weatherData.current.wind_mph : ""}<p style={{fontSize:'30px', display:'inline',}}> mph</p></h1>
            {weatherData ? <i className="fa-sharp fa-solid fa-wind fa-beat-fade"></i> : ""}
          </div>
          <div className="col-3 d2">Humidity
          <h1 className='set_margin'>{weatherData ? weatherData.current.humidity : ""}<p style={{fontSize:'30px', display:'inline'}}> %</p></h1>
          <meter min="0" max="100" value={weatherData ? weatherData.current.humidity : 0}></meter>
          </div>
        </div>
        <div className="row">
          <div className="col-3 d2">Visibility
            <h1 className='set_margin'>{weatherData ? weatherData.current.vis_miles : ""}<p style={{fontSize:'30px', display:'inline'}}> miles</p></h1>
          </div>
          <div className="col-3 d2">Air Pressure
            <h1 className='set_margin'>{weatherData ? weatherData.current.pressure_mb : ""}<p style={{fontSize:'30px', display:'inline'}}> mb</p></h1>
          </div> 
        </div>
      </div>
    </div>
  );
}

export default App;
